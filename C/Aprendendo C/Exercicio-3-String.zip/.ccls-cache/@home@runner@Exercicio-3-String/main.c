/* **EXEMPLO 3**: Fazer um algoritmo que leia várias palavras e

  exiba na tela o tamanho da MAIOR e da MENOR palavra lida entre todas.

  Pare o programa quando o usuário digitar a string: "SAIR". */

#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}