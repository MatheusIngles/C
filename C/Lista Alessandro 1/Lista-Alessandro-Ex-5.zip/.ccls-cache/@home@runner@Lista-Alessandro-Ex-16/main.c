#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(void) {
  printf("Hello World\n");
  return 0;
}