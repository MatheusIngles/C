//  Escrever um programa em C que leia várias mensagens (uma por uma) e exiba na
//  tela a quantidade
// de vezes que aparece na mensagem lida uma outra palavra escolhida pelo
// usuário, a cada nova mensagem. Pare o programa quando for digitada a palavra
// “FIM” ou "fim".

#include <stdio.h>
#include <string.h>

#define Tamanho 1000

int main(void) {

  char txt[Tamanho];

  do {
    printf(" Qual a palavra que você quer: ");
    scan
  } while (1);

  printf("Hello World\n");
  return 0;
}